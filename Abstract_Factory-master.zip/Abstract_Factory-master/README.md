# Abstract_Factory
 
Working through Gary Woodfine's "How to use the Abstract Factory design pattern in C#"
https://garywoodfine.com/abstract-factory-design-pattern/
