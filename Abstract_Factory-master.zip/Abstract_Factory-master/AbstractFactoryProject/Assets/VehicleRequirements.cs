﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VehicleRequirements
{
    public int NumberOfWheels;
    public bool Engine;
    public int Passengers;
}
